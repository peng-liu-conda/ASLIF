# ASLIF fusion implementation

This repository packages the ASLIF fusion and postprocessing used in the final frozen run. It accepts an existing Mask R-CNN soft probability map, an O2SFormer binary mask, scene class, lane counts, and branch confidence scores. It does **not** include model weights, datasets, or upstream model inference.

## Install

```bash
python -m pip install -r requirements.txt
```

## Run

```bash
python run_aslif.py --maskrcnn-soft m.npz --o2-mask o.png --scene 0 --m-count 3 --o-count 4 --m-confidence 0.8 --o-confidence 0.7 --output fused.png
```

`m.npz` must contain a 2D array named `soft_mask` with values in `[0, 1]`. `o.png` must be a same-size binary mask (nonzero means foreground). Scene indices are `0=normal`, `1=multi-lane`, `2=complex`. The output is an 8-bit binary PNG; the command also prints the computed alpha.

The locked parameters are `lambda_s=0.2727272727272727`, `lambda_n=0.409090909090909`, `lambda_c=0.3181818181818181`, threshold `0.5`, and 8-connected component minimum area `500` pixels. Alpha weights O2SFormer: `(1-alpha)*M + alpha*O`.

## Scope and provenance

The implementation follows the final run's raw branch confidence convention: mean valid Mask R-CNN instance score and mean finite O2SFormer lane score, or zero when no valid score exists. The manuscript's temperature-scaled confidence description differs from this executable convention; do not claim that this package implements calibrated confidence.

The original experiment also depended on a frozen VAL100 selection set and TEST300 evaluation set. Neither data nor weights are redistributed here. The code in this package is a standalone extraction of the final fusion step; published metrics cannot be reproduced from this repository alone.
